export { ReactComponent as CloseIcon } from "./svg/CloseIcon.svg";
